# TrackletGraphs
Repository constructing graphs of tracklets (doublets, triplets, quadruplets, etc...) for particle physics applications.
Graph construction of each tracklet type is followed by filtering and ambiguity graph contruction sub-stage.
And finally disconnecting the graphs to get well-defined tracks.

## Cloning Instruction:
```
git clone git@github.com:tkar-git/TrackletGraphs.git
```
