def main(config):
    raise NotImplementedError("Disconnecting stage not implemented yet")