def main():
    print("test")