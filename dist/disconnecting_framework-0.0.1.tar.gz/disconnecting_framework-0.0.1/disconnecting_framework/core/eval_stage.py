def main(config_file):
    raise NotImplementedError